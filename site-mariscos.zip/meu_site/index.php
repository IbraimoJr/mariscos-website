<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mariscos Kay - Página Inicial</title>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
  

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
       font-family: 'Open Sans', sans-serif;
      background-color: #f8f9fa;
      
    }
  

.custom-navbar {
  background: linear-gradient(to right, rgba(0, 47, 75, 0.75), rgba(0, 106, 113, 0.75));
  border-radius: 12px;
  max-width: 85%;
  margin: -60px auto 20px auto;
  padding: 12px 30px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  position: relative;
  z-index: 1000;
  font-family: 'Open Sans', sans-serif;
  font-size: 17px;
  border: 1px solid rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(6px); /* para efeito de vidro fosco */
}

/* Estilo dos links */
.custom-navbar a {
  position: relative;
  color: #ffffff;
  text-decoration: none;
  font-weight: 600;
  letter-spacing: 0.8px;
  padding: 10px 15px;
  transition: color 0.3s ease, transform 0.3s ease;
}

/* Underline no hover */
.custom-navbar a::after {
  content: "";
  position: absolute;
  left: 50%;
  bottom: 5px;
  transform: translateX(-50%);
  height: 2px;
  width: 0;
  background-color: #00c6ff;
  transition: width 0.3s ease;
}

/* Efeitos ao passar o mouse */
.custom-navbar a:hover {
  color: #00c6ff;
  transform: translateY(-2px);
}

.custom-navbar a:hover::after {
  width: 100%;
}

/* Estilo quando o menu estiver fixo no topo */
.fixed-navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  margin: 0 auto;
  background: rgba(0, 0, 0, 0.45); /* torna mais opaco ao fixar */
  border-radius: 0;
  max-width: 100%;
  width: 100%;
  padding: 10px 0;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
}

/* Fixar altura padrão dos slides */
.carrossel-slide-content {
      min-height: 420px;
      padding: 30px;
      background: white;
    }
    .carrossel-img {
      width: 100%;
      height: 300px;
      object-fit: cover;
      border-radius: 8px;
    }
    .carousel-indicators [data-bs-target] {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: #ff4500;
    }


.hero {
  position: relative;
  text-align: center;
  padding: 100px 20px 80px;
  overflow: hidden;
  background: linear-gradient(to bottom, #e0f7fa, #ffffff);
}

.hero h1 {
  font-family: 'Pacifico', cursive;
  font-size: 3.5rem;
  background: linear-gradient(90deg, #ff6f61, #ffa07a, #ff6f61);
  background-size: 200% auto;
  color: transparent;
  background-clip: text;
  -webkit-background-clip: text;
  animation: waveColor 5s linear infinite, fadeInUp 1.2s ease-out;
  text-shadow: 2px 2px 5px rgba(0,0,0,0.2);
  z-index: 1;
  position: relative;
}

/* Peixinho animado */
.hero .fish {
  position: absolute;
  top: 20px;
  font-size: 2.5rem;
  animation: swim 6s ease-in-out infinite;
}

/* Bolhas subindo */
.bubbles span {
  position: absolute;
  bottom: -50px;
  width: 15px;
  height: 15px;
  background: rgba(173, 216, 230, 0.7);
  border-radius: 50%;
  animation: bubbleUp 5s linear infinite;
  left: calc(10% * var(--i));
}

@keyframes bubbleUp {
  0% {
    transform: translateY(0) scale(1);
    opacity: 1;
  }
  100% {
    transform: translateY(-200px) scale(0.6);
    opacity: 0;
  }
}

/* Animação da cor do texto (onda) */
@keyframes waveColor {
  0% {
    background-position: 0% center;
  }
  100% {
    background-position: 200% center;
  }
}

/* Entrada suave */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(40px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Animação do peixe */
@keyframes swim {
  0% {
    left: -10%;
    transform: scaleX(1);
  }
  50% {
    left: 50%;
    transform: scaleX(-1);
  }
  100% {
    left: 110%;
    transform: scaleX(1);
  }
}


    .card img {
      height: 200px;
      object-fit: cover;
    }
    footer {
      background-color: #343a40;
      color: white;
      padding: 20px 0;
    }

   /* receitas de mariscos */

      .recipe-block {
      display: flex;
      margin-bottom: 30px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: 0.3s;
    }
    .recipe-block:hover {
      transform: translateY(-4px);
    }
    .recipe-img {
      width: 50%;
      background-size: cover;
      background-position: center;
      position: relative;
      display: flex;
      align-items: end;
      padding: 20px;
      color: #fff;
    }
    .recipe-overlay {
      background: linear-gradient(to right, rgba(0, 47, 75, 0.75), rgba(0, 106, 113, 0.75));
      padding: 5px 45px;
      border-radius: 5px;
      
    }
    .recipe-info {
      width: 60%;
      padding: 70px;
    }
    .badge-custom {
      background-color: #ff7f50;
      color: white;
      margin-right: 8px;
    }
    .btn-leia {
      background: linear-gradient(to right, rgba(0, 47, 75, 0.75), rgba(0, 106, 113, 0.75));
      color: #fff;
      border: none;
    }
    .btn-leia:hover {
      background-color: #e04e00;
    }
   
      .card-img-top { height: 200px; object-fit: cover; }
    .badge { text-transform: uppercase; }
    .card { border-radius: 15px; overflow: hidden; box-shadow: 0 0 10px rgba(0,0,0,0.1); transition: 0.3s; }
    .card:hover { transform: scale(1.02); }
    .buy-btn {  background: linear-gradient(to right, rgba(0, 47, 75, 0.75), rgba(0, 106, 113, 0.75)); border: none; }
    .buy-btn:hover { background: #e04e00; }

    .info-mariscoskay {
    background: rgba(255, 255, 255, 0.95);
    border-left: 6px solid #dc3545;
    padding: 25px;
    margin: 40px auto;
    max-width: 900px;
    font-family: 'Poppins', sans-serif;
    font-size: 1.1rem;
    line-height: 1.8;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-radius: 8px;
     text-align: justify; /* <- JUSTIFICAR o texto */
  }

  .info-mariscoskay strong {
    color: #b02a37;
  }
  </style>
</head>
<body>

<!-- Navbar -->
<!-- Header Principal -->
<!-- HEAD: Bootstrap + Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<!-- Header -->
<header class="text-white position-relative" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('img/back12.jpg'); background-size: cover; background-position: center; padding: 10px 0;">
    
  <div class="container py-3 d-flex justify-content-between align-items-center">

    <!-- Logo -->
    <img src="img/logo1-Photoroom.png" alt="Logo" height="180">

    <!-- Botões e carrinho -->
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-outline-white text-white" style="text-shadow: 2px 2px 5px black;">ENTRAR</button>
      <button class="btn btn-light text-danger" style="text-shadow: 2px 2px 5px black;">REGISTAR</button>
      <div class="text-center">
        <span class="d-block fw-bold" style="text-shadow: 2px 2px 5px black;">Compre aqui!</span>
        <a href="carrinho.php" class="btn btn-outline-black position-relative">
          <i class="bi bi-cart text-danger" style="font-size: 19px; text-shadow: 2px 2px 5px black;">  MT0.00</i> 
        
        </a>
      </div>
    </div>
  </div>

  <!-- Navegação -->
 <nav class="custom-navbar text-center">
  <div class="container d-flex justify-content-center gap-4 flex-wrap">
    <a href="#">Home</a>
    <a href="#">Promoções</a>
    <a href="#">Receitas</a>
    <a href="#">Contacto</a>
    <a href="#">Sobre Nós</a>

  </div>
</nav>


  <!-- Título principal -->
  <div class="text-center py-4">
  <h2 class="fw-bold" style=" text-shadow: 2px 2px 5px black; font-family: 'Pacifico', cursive; color: #ffffff; font-size: 3rem;">
  PEIXES e MARISCOS
</h2>


  </div>
</header>
<?php include 'db.php'; ?>


<div class="container mt-5">
  <div id="carrosselMariscos" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
    <div class="carousel-inner">
      <?php
      $sql = "SELECT * FROM slides WHERE status = 1 ORDER BY id DESC";
      $res = $conn->query($sql);
      $active = true;
      while ($row = $res->fetch_assoc()) {
      ?>
        <div class="carousel-item <?= $active ? 'active' : '' ?>">
          <div class="d-flex flex-column flex-md-row align-items-center carrossel-slide-content">
            <div class="col-md-6 text-center text-md-start p-4">
              <h1 class="display-5 fw-bold"><?= $row['titulo'] ?></h1>
              <p class="lead"><?= $row['descricao'] ?> — MT <?= $row['preco'] ?></p>
              <a href="#" class="btn btn-danger btn-lg mt-3">COMPRE AGORA!</a>
              <p class="text-success mt-2">Satisfação total garantida!</p>
            </div>
            <div class="col-md-6">
              <img src="uploads/<?= $row['imagem'] ?>" class="carrossel-img" alt="Imagem">
            </div>
          </div>
        </div>
      <?php $active = false; } ?>
    </div>

    <div class="carousel-indicators">
      <?php for ($i = 0; $i < $res->num_rows; $i++): ?>
        <button type="button" data-bs-target="#carrosselMariscos" data-bs-slide-to="<?= $i ?>" class="<?= $i === 0 ? 'active' : '' ?>"></button>
      <?php endfor; ?>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#carrosselMariscos" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carrosselMariscos" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
    </div>
</div>



<!-- Hero -->
  <div class="hero">
  <div class="bubbles">
    <span style="--i:1;"></span>
    <span style="--i:3;"></span>
    <span style="--i:5;"></span>
    <span style="--i:7;"></span>
  </div>
  <span class="fish">🐟</span>
   <h1>MariscosKay: O Guia Completo para Sabores do Oceano</h1>
</div>



<!-- Produtos em Destaque -->
<section class="py-5">
 <div class="container py-5">
  <h1 class="mb-4 text-center" style="font-family: 'Pacifico', cursive;">Mariscos Disponíveis</h1>
  <div class="row">
    <?php
    $sql = "SELECT * FROM produtos ORDER BY id DESC";
    $res = $conn->query($sql);
    while ($row = $res->fetch_assoc()) {
      $badgeColor = $row['estado'] == 'promocao' ? 'bg-warning' : ($row['estado'] == 'esgotado' ? 'bg-danger' : 'bg-success');
    ?>
    <div class="col-md-4 mb-4">
      <div class="card">
        <img src="uploads/<?= $row['imagem'] ?>" class="card-img-top" alt="<?= $row['nome'] ?>">
        <div class="card-body">
          <h5 class="card-title"><?= $row['nome'] ?></h5>
          <p class="card-text"><?= substr($row['descricao'], 0, 100) ?>...</p>
          <span class="badge <?= $badgeColor ?>"><?= $row['estado'] ?></span>
          <h4 class="mt-2 text-primary">MZN <?= number_format($row['preco'], 2, ',', '.') ?></h4>
          <button class="btn btn-warning text-white mt-2 buy-btn w-100" <?= $row['estado'] == 'esgotado' ? 'disabled' : '' ?>>Comprar</button>
        </div>
      </div>
    </div>
    <?php } ?>
  </div>
</div>
</section>

<!-- Receitas em Destaque -->


<div class="info-mariscoskay">
  <p>
    <strong>MariscosKay</strong> é a sua referência de confiança quando se trata de mariscos frescos e selecionados com rigor. 
    Oferecemos uma vasta variedade de produtos do mar, sempre com o compromisso de garantir frescura, qualidade e sabor autêntico. 
    Dos camarões aos caranguejos, cada item é escolhido cuidadosamente para proporcionar uma experiência única à sua mesa. 
    Confie na <strong>MariscosKay</strong> para os melhores mariscos, ideais tanto para o seu dia a dia como para momentos especiais.
  </p>
</div>



<div class="container py-5">
  <h1 class="text-center mb-5" style="font-family: 'Pacifico', cursive;">Receitas de Mariscos</h1>
  <?php
  $sql = "SELECT * FROM receitas ORDER BY id DESC";
  $res = $conn->query($sql);
  while ($row = $res->fetch_assoc()) {
  ?>
    <div class="recipe-block">
      <div class="recipe-img" style="background-image: url('uploads/<?= $row['imagem'] ?>');">
        <div class="recipe-overlay">
          <h4><?= $row['titulo'] ?></h4>
        </div>
      </div>
      <div class="recipe-info">
        <span class="badge badge-custom"><?= $row['dificuldade'] ?></span>
        <span class="badge badge-custom"><?= $row['tempo_preparo'] ?></span>
        <p class="mt-3"><?= substr($row['descricao'], 0, 120) ?>...</p>
        <a href="receitas/ver.php?id=<?= $row['id'] ?>" class="btn btn-leia">Ler mais</a>
      </div>
    </div>
  <?php } ?>
</div>



<!-- Footer -->
<footer class="text-center">
  <div class="container">
    <p class="mb-1">© 2025 Mariscos Kay - Todos os direitos reservados</p>
    <small>Feito com ♥ em Moçambique</small>
  </div>
</footer>
<script>
  window.addEventListener("scroll", function () {
    const navbar = document.querySelector(".custom-navbar");
    if (window.scrollY > 50) {
      navbar.classList.add("fixed-navbar");
    } else {
      navbar.classList.remove("fixed-navbar");
    }
  });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
