
<?php include '../db.php'; ?>
<?php
$id = $_GET['id'];
$sql = "SELECT * FROM receitas WHERE id = $id";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title><?= $row['titulo'] ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h1 class="mb-4"><?= $row['titulo'] ?></h1>
  <img src="../uploads/<?= $row['imagem'] ?>" class="img-fluid rounded mb-4" style="max-height:400px;object-fit:cover;">
  <p><?= nl2br($row['descricao']) ?></p>
  <a href="index.php" class="btn btn-secondary mt-3">← Voltar</a>
</div>
</body>
</html>
