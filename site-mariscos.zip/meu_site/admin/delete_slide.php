
<?php include '../db.php'; ?>
<?php
$id = $_GET['id'];
$sql = "DELETE FROM slides WHERE id = $id";
$conn->query($sql);
header("Location: dashboard.php");
?>
