
<?php include '../../db.php'; ?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Painel de Receitas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h2 class="mb-4">Gestão de Receitas</h2>
  <a href="add.php" class="btn btn-success mb-3">+ Nova Receita</a>
  <table class="table table-bordered bg-white">
    <thead><tr><th>#</th><th>Título</th><th>Imagem</th><th>Ações</th></tr></thead>
    <tbody>
      <?php
      $sql = "SELECT * FROM receitas ORDER BY id DESC";
      $res = $conn->query($sql);
      while ($row = $res->fetch_assoc()) {
      ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['titulo'] ?></td>
        <td><img src="../../uploads/<?= $row['imagem'] ?>" width="100"></td>
        <td>
          <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">Editar</a>
          <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza?')">Excluir</a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>
