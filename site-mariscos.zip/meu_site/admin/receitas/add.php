<?php include '../../db.php'; ?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Adicionar Receita</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h2 class="mb-4">Adicionar Nova Receita</h2>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Título da Receita:</label>
      <input type="text" name="titulo" class="form-control" required>
    </div>

    <div class="mb-3">
      <label>Descrição:</label>
      <textarea name="descricao" class="form-control" rows="5" required></textarea>
    </div>

    <div class="mb-3">
      <label>Imagem:</label>
      <input type="file" name="imagem" class="form-control" required>
    </div>

    <div class="mb-3">
      <label>Tempo de Preparo:</label>
      <input type="text" name="tempo_preparo" class="form-control" placeholder="ex: 30 min" required>
    </div>

    <div class="mb-3">
      <label>Dificuldade:</label>
      <select name="dificuldade" class="form-control" required>
        <option value="Fácil">Muito fácil</option>
        <option value="Média">Médio</option>
        <option value="Difícil">Difícil</option>
      </select>
    </div>

    <button type="submit" name="salvar" class="btn btn-success">Salvar Receita</button>
    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>

<?php
if (isset($_POST['salvar'])) {
  $titulo = $_POST['titulo'];
  $descricao = $_POST['descricao'];
  $tempo = $_POST['tempo_preparo'];
  $dificuldade = $_POST['dificuldade'];

  $imagem = $_FILES['imagem']['name'];
  $tmp = $_FILES['imagem']['tmp_name'];
  move_uploaded_file($tmp, '../../uploads/' . $imagem);

  $sql = "INSERT INTO receitas (titulo, descricao, imagem, tempo_preparo, dificuldade) 
          VALUES ('$titulo', '$descricao', '$imagem', '$tempo', '$dificuldade')";
  if ($conn->query($sql)) {
    header("Location: dashboard.php");
  } else {
    echo "<div class='alert alert-danger mt-3'>Erro: " . $conn->error . "</div>";
  }
}
?>
</body>
</html>
