
<?php include '../db.php'; ?>
<?php
$id = $_GET['id'];
$sql = "SELECT * FROM slides WHERE id = $id";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Editar Slide</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2 class="mb-4">Editar Slide</h2>
  <form action="" method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Título:</label>
      <input type="text" name="titulo" class="form-control" value="<?= $row['titulo'] ?>" required>
    </div>
    <div class="mb-3">
      <label>Descrição:</label>
      <input type="text" name="descricao" class="form-control" value="<?= $row['descricao'] ?>" required>
    </div>
    <div class="mb-3">
      <label>Preço:</label>
      <input type="number" name="preco" class="form-control" value="<?= $row['preco'] ?>" step="0.01" required>
    </div>
    <div class="mb-3">
      <label>Imagem Atual:</label><br>
      <img src="../uploads/<?= $row['imagem'] ?>" width="150"><br><br>
      <input type="file" name="imagem" class="form-control">
    </div>
    <button type="submit" name="atualizar" class="btn btn-primary">Atualizar</button>
    <a href="dashboard.php" class="btn btn-secondary">Voltar</a>
  </form>
</div>

<?php
if (isset($_POST['atualizar'])) {
  $titulo = $_POST['titulo'];
  $descricao = $_POST['descricao'];
  $preco = $_POST['preco'];
  $imagem = $row['imagem'];
  if (!empty($_FILES['imagem']['name'])) {
    $imagem = $_FILES['imagem']['name'];
    move_uploaded_file($_FILES['imagem']['tmp_name'], "../uploads/" . $imagem);
  }
  $sql = "UPDATE slides SET titulo='$titulo', descricao='$descricao', preco='$preco', imagem='$imagem' WHERE id=$id";
  if ($conn->query($sql)) {
    header("Location: dashboard.php");
  }
}
?>
</body>
</html>
