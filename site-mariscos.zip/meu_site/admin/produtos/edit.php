<?php
include '../../db.php';

$id = $_GET['id'];
$dados = $conn->query("SELECT * FROM produtos WHERE id = $id")->fetch_assoc();

if (isset($_POST['salvar'])) {
  $nome = $_POST['nome'];
  $preco = $_POST['preco'];
  $descricao = $_POST['descricao'];
  $estado = $_POST['estado'];

  if (!empty($_FILES['imagem']['name'])) {
    $img = $_FILES['imagem']['name'];
    $tmp = $_FILES['imagem']['tmp_name'];
    move_uploaded_file($tmp, "../../uploads/" . $img);
  } else {
    $img = $dados['imagem'];
  }

  $sql = "UPDATE produtos SET nome='$nome', preco='$preco', descricao='$descricao', estado='$estado', imagem='$img' WHERE id=$id";

  if ($conn->query($sql)) {
    header("Location: dashboard.php");
  } else {
    echo "Erro: " . $conn->error;
  }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Editar Produto</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h2 class="mb-4">Editar Produto</h2>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Nome do Produto:</label>
      <input type="text" name="nome" class="form-control" value="<?= $dados['nome'] ?>" required>
    </div>

    <div class="mb-3">
      <label>Preço (MZN):</label>
      <input type="number" name="preco" class="form-control" step="0.01" value="<?= $dados['preco'] ?>" required>
    </div>

    <div class="mb-3">
      <label>Descrição:</label>
      <textarea name="descricao" class="form-control" rows="4"><?= $dados['descricao'] ?></textarea>
    </div>

    <div class="mb-3">
      <label>Estado:</label>
      <select name="estado" class="form-control" required>
        <option value="disponivel" <?= $dados['estado'] == 'disponivel' ? 'selected' : '' ?>>Disponível</option>
        <option value="esgotado" <?= $dados['estado'] == 'esgotado' ? 'selected' : '' ?>>Esgotado</option>
        <option value="promocao" <?= $dados['estado'] == 'promocao' ? 'selected' : '' ?>>Promoção</option>
      </select>
    </div>

    <div class="mb-3">
      <label>Imagem:</label><br>
      <img src="../../uploads/<?= $dados['imagem'] ?>" width="150"><br><br>
      <input type="file" name="imagem" class="form-control">
    </div>

    <button type="submit" name="salvar" class="btn btn-primary">Salvar Alterações</button>
    <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
</body>
</html>
