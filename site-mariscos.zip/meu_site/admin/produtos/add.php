
<?php include '../../db.php'; ?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Adicionar Produto</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h2 class="mb-4">Novo Produto</h2>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Nome:</label>
      <input type="text" name="nome" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Descrição:</label>
      <textarea name="descricao" class="form-control" rows="4" required></textarea>
    </div>
    <div class="mb-3">
      <label>Preço (MZN):</label>
      <input type="number" step="0.01" name="preco" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Imagem:</label>
      <input type="file" name="imagem" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Estado:</label>
      <select name="estado" class="form-control">
        <option value="disponivel">Disponível</option>
        <option value="esgotado">Esgotado</option>
        <option value="promocao">Promoção</option>
      </select>
    </div>
    <button name="salvar" class="btn btn-success">Salvar</button>
    <a href="dashboard.php" class="btn btn-secondary">Voltar</a>
  </form>
</div>
<?php
if (isset($_POST['salvar'])) {
  $nome = $_POST['nome'];
  $descricao = $_POST['descricao'];
  $preco = $_POST['preco'];
  $estado = $_POST['estado'];
  $img = $_FILES['imagem']['name'];
  $tmp = $_FILES['imagem']['tmp_name'];
  move_uploaded_file($tmp, '../../uploads/' . $img);
  $conn->query("INSERT INTO produtos (nome, descricao, preco, imagem, estado) VALUES ('$nome','$descricao','$preco','$img','$estado')");
  header('Location: dashboard.php');
}
?>
</body>
</html>
