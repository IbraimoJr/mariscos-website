
<?php include '../../db.php'; ?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Admin - Produtos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h2 class="mb-4">Gestão de Produtos</h2>
  <a href="add.php" class="btn btn-success mb-3">+ Novo Produto</a>
  <table class="table table-bordered bg-white">
    <thead><tr><th>#</th><th>Nome</th><th>Imagem</th><th>Preço</th><th>Estado</th><th>Ações</th></tr></thead>
    <tbody>
      <?php
      $sql = "SELECT * FROM produtos ORDER BY id DESC";
      $res = $conn->query($sql);
      while ($row = $res->fetch_assoc()) {
      ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['nome'] ?></td>
        <td><img src="../../uploads/<?= $row['imagem'] ?>" width="100"></td>
        <td>MZN <?= number_format($row['preco'], 2, ',', '.') ?></td>
        <td><?= ucfirst($row['estado']) ?></td>
        <td>
      <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
<a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja apagar este produto?')">Apagar</a>

        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>
