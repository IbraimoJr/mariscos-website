<?php
include '../../db.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];

  // (Opcional) Apagar a imagem do produto
  $getImg = $conn->query("SELECT imagem FROM produtos WHERE id = $id");
  if ($getImg->num_rows > 0) {
    $img = $getImg->fetch_assoc()['imagem'];
    if (file_exists("../../uploads/" . $img)) {
      unlink("../../uploads/" . $img);
    }
  }

  $conn->query("DELETE FROM produtos WHERE id = $id");
}

header("Location: dashboard.php");
?>
