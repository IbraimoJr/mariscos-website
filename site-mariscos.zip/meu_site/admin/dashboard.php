
<?php include '../db.php'; ?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Painel de Slides</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <h2 class="mb-4">Gestão de Slides</h2>
  <a href="add_slide.php" class="btn btn-success mb-3">+ Adicionar Novo Slide</a>
  <table class="table table-bordered bg-white">
    <thead>
      <tr>
        <th>#</th>
        <th>Título</th>
        <th>Descrição</th>
        <th>Preço</th>
        <th>Imagem</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php
        $sql = "SELECT * FROM slides ORDER BY id DESC";
        $res = $conn->query($sql);
        while ($row = $res->fetch_assoc()) {
      ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['titulo'] ?></td>
        <td><?= $row['descricao'] ?></td>
        <td>R$ <?= $row['preco'] ?></td>
        <td><img src="../uploads/<?= $row['imagem'] ?>" width="100"></td>
        <td>
          <a href="edit_slide.php?id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">Editar</a>
          <a href="delete_slide.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>
